﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObject
{
    public partial class Status
    {
        public int StatusID { get; set; }
        public string StatusName { get; set; }
    }
}
